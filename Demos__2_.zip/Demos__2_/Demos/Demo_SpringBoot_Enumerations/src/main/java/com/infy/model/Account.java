package com.infy.model;

public class Account

{

	/**
	 * 
	 * @Id is used to map primary key of this table
	 * 
	 * 
	 * 
	 * @column is used to map a property with a column in table where column
	 *         name is different
	 * 
	 *         in this case 'accountId' is mapped with ACCOUNT_ID column of this
	 *         table
	 * 
	 * */

	private Integer accountId;

	private String accountNumber;

	private Integer branchId;

	private Double balance;

	private AccountStatus accountStatus;

	public Integer getAccountId() {

		return accountId;

	}

	public void setAccountId(Integer accountId) {

		this.accountId = accountId;

	}

	public String getAccountNumber() {

		return accountNumber;

	}

	public void setAccountNumber(String accountNumber) {

		this.accountNumber = accountNumber;

	}

	public Integer getBranchId() {

		return branchId;

	}

	public void setBranchId(Integer branchId) {

		this.branchId = branchId;

	}

	public Double getBalance() {

		return balance;

	}

	public void setBalance(Double balance) {

		this.balance = balance;

	}

	public AccountStatus getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(AccountStatus accountStatus) {
		this.accountStatus = accountStatus;
	}

}