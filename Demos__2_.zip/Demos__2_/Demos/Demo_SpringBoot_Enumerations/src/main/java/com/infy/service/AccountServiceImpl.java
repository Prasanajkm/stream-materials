package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.AccountDAO;

import com.infy.model.Account;


@Service(value = "accountService")
@Transactional
public class AccountServiceImpl implements AccountService {

	@Autowired
	private AccountDAO accountDAO;

	@Override
	@Transactional
	public String addAccount(Account account) throws Exception {
		String accountNumber = accountDAO.addAccount(account);
		return accountNumber;
	}

}