package com.infy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.infy.model.Account;
import com.infy.model.AccountStatus;
import com.infy.service.AccountService;

@SpringBootApplication
public class DemoSpringBootEnumerationsApplication implements CommandLineRunner {
	
	@Autowired
	AccountService accountService;
	@Autowired
	Environment environment;

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringBootEnumerationsApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		addAccount();

	}

	public void addAccount() {
		try {
			Account account = new Account();
			account.setAccountId(1015848);
			account.setAccountNumber("312449811015848");
			account.setAccountStatus(AccountStatus.ACTIVE);
			account.setBalance(10000.0);
			account.setBranchId(5123);
			
			String acccountNumber = accountService.addAccount(account);
			System.out.println("\n"
					+ environment
							.getProperty("UserInterface.ACCOUNT_ADDED")
					+ acccountNumber);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage());
			if (message == null) {
				message = environment.getProperty("General.EXCEPTION");
			}
			System.out.println("\nERROR:" + message);
		}

	}

}

