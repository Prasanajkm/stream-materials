package com.infy.service;

import com.infy.model.Customer;

public interface CustomerService {
	public Customer getCustomer(Integer customerId) throws Exception;
}
