package com.infy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.core.env.Environment;

import com.infy.model.Customer;
import com.infy.service.CustomerService;

@SpringBootApplication
@EnableCaching
public class DemoSpringBootCachingApplication implements CommandLineRunner {
	
	@Autowired
	CustomerService customerService;

	@Autowired
	Environment environment;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoSpringBootCachingApplication.class, args);
	}

	public void run(String... args) throws Exception {

		getCustomer();
		getCustomer();
		getCustomer();
		
	}
	
	public  void getCustomer() {
		try {

			
			Customer customer = customerService.getCustomer(1001);

			//Customer customer1 = customerService.getCustomer(1001);
			System.out.println("Customer id : " + customer.getCustomerId());
			System.out.println("Customer name : " + customer.getName());
			System.out.println("Customer email : " + customer.getEmailId());

		} catch (Exception e) {
			e.printStackTrace();
			if (e.getMessage() != null)
				System.out
				.println(environment.getProperty(e.getMessage(),
						"Something went wrong. Please check log file for more details."));
		}
	}
}

