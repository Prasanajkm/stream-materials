package com.infy.dao;

import com.infy.model.Customer;

public interface CustomerDAO {
	public Customer getCustomer(Integer customerId) throws Exception;
}
