package com.infy.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.CustomerDAO;

@Service(value = "customerDetailsService")
@Transactional
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerDAO customerDAO;

	@Override
	public Double getAverageBalance() throws Exception {
		// TODO Auto-generated method stub
		return customerDAO.getAverageBalance();
	}

	@Override
	public Long getTotalBalance() throws Exception {
		// TODO Auto-generated method stub
		return customerDAO.getTotalBalance();
	}

	@Override
	public Long getNumberOfAccounts() throws Exception {
		// TODO Auto-generated method stub
		return customerDAO.getNumberOfAccounts();
	}

	@Override
	public Integer getMinimumBalance() throws Exception {
		// TODO Auto-generated method stub
		return customerDAO.getMinimumBalance();
	}

	@Override
	public Integer getMaximumBalance() throws Exception {
		// TODO Auto-generated method stub
		return customerDAO.getMaximumBalance();
	}
	
	

}
