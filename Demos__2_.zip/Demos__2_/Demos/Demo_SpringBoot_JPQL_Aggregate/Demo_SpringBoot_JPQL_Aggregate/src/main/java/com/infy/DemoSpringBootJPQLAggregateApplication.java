package com.infy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.infy.service.CustomerService;

@SpringBootApplication
public class DemoSpringBootJPQLAggregateApplication implements CommandLineRunner {

	@Autowired
	CustomerService service;

	@Autowired
	Environment environment;
	
	public static void main(String[] args) {
		SpringApplication.run(DemoSpringBootJPQLAggregateApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

//		getAverageBalance();
//		getTotalBalance();
//		getNumberOfAccounts();
//		getMinimumBalance();
//		getMaximumBalance();


	}

	public void getMaximumBalance() {
		Integer maxBalance;
		try {
			maxBalance = service.getMaximumBalance();
			System.out.println(environment.getProperty("UserInterface.MAX_BALANCE")+maxBalance);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage(),"Some exception occured. Please check log file for more details!!");
			System.out.println( message);
		}
		
		
	}

	public void getMinimumBalance() {
		Integer minimumBalance;
		try {
			minimumBalance = service.getMinimumBalance();
			System.out.println(environment.getProperty("UserInterface.MIN_BALANCE")+minimumBalance);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage(),"Some exception occured. Please check log file for more details!!");
			System.out.println( message);
		}
		
	}

	public void getNumberOfAccounts() {
		Long numberOfAccounts;
		try {
			numberOfAccounts = service.getNumberOfAccounts();
			System.out.println(environment.getProperty("UserInterface.NO_OF_ACCOUNTS")+numberOfAccounts);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage(),"Some exception occured. Please check log file for more details!!");
			System.out.println( message);
		}
		
	}

	public void getTotalBalance() {
		Long totalBalance;
		try {
			totalBalance = service.getTotalBalance();
			System.out.println(environment.getProperty("UserInterface.TOTAL_BALANCE")+totalBalance);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage(),"Some exception occured. Please check log file for more details!!");
			System.out.println( message);
		}
		
	}

	public void getAverageBalance() {
		Double averageBalance;
		try {
			averageBalance = service.getAverageBalance();
			System.out.println(environment.getProperty("UserInterface.AVERAGE_BALANCE")+averageBalance);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage(),"Some exception occured. Please check log file for more details!!");
			System.out.println( message);
		}
		
	}

	

}

