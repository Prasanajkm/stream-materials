package com.infy.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;


@Repository(value="customerDAO")
public class CustomerDAOImpl implements CustomerDAO {

	@PersistenceContext
	private EntityManager entityManager;


	@Override
	public Double getAverageBalance() throws Exception {
		String queryString1 ="SELECT AVG(a.balance) FROM AccountEntity a";

		Query query=entityManager.createQuery(queryString1);

		Double result = (Double) query.getSingleResult();
		
		return result;
	}

	@Override
	public Long getTotalBalance() throws Exception {
		// TODO Auto-generated method stub

		String queryString ="SELECT SUM(a.balance) FROM AccountEntity a";

		Query query=entityManager.createQuery(queryString);

		Long result = (Long) query.getSingleResult();
		
		return result;
	}

	@Override
	public Long getNumberOfAccounts() throws Exception {
		String queryString ="SELECT COUNT(a) FROM AccountEntity a";

		Query query=entityManager.createQuery(queryString);

		Long result = (Long)query.getSingleResult();
		
		return result;
	}

	@Override
	public Integer getMinimumBalance() throws Exception {
		
		String queryString ="SELECT MIN(a.balance) FROM AccountEntity a";

		Query query=entityManager.createQuery(queryString);

		Integer result = (Integer) query.getSingleResult();
		
		return result;
	}

	@Override
	public Integer getMaximumBalance() throws Exception {
		
		String queryString ="SELECT MAX(a.balance) FROM AccountEntity a";

		Query query=entityManager.createQuery(queryString);

		Integer result = (Integer)query.getSingleResult();
		
		return result;
	}


}
