drop table account cascade constraints;
drop table customer cascade constraints;
create table account (
	account_number number(10) not null,
	account_status varchar2(10),
	account_type varchar2(10),
	balance number(10),
	opening_date date,
	cust_id number(10),
	primary key (account_number)
);
create table customer (
	customer_id number(10) not null,
	city varchar2(10),
	date_of_birth date,
	emailid varchar2(20),
	name varchar2(20),
	primary key (customer_id)
);
alter table account add constraint fk_accnt_cust foreign key (cust_id) references customer;

insert into customer (customer_id, city, date_of_birth, emailid,name) values (1001,'Bangalore','10-Jan-1992','monica@infy.com','Monica');
insert into customer (customer_id, city, date_of_birth, emailid,name) values (1002,'Mysore','23-Apr-1996',null,'Roger');


insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5001,'ACTIVE','Savings',12345,'25-Oct-2016',1001);
insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5002,'ACTIVE','Current',899567,'21-Jan-2015',1001);
insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5003,'INACTIVE','Loan',617345,'12-Nov-2016',1002);
insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5004,'ACTIVE','Savings',345324,'08-Dec-2017',1002);
insert into account (account_number,account_status, account_type, balance, opening_date, cust_id) values (5005,'ACTIVE','Demat',45324,'08-Apr-2017',1001);

commit;
