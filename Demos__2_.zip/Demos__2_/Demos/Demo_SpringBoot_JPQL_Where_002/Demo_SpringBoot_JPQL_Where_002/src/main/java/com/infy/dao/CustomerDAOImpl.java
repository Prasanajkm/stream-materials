package com.infy.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.infy.entity.AccountEntity;
import com.infy.entity.CustomerEntity;
import com.infy.model.Account;
import com.infy.model.Customer;


@Repository(value="customerDAO")
public class CustomerDAOImpl implements CustomerDAO {

	@PersistenceContext
	private EntityManager entityManager;

	public List<Customer> getCustomerdetails(Integer customerId) throws Exception {
		List<Customer> customerList=null;


		//Comment the below 3 lines while using named parameter
		String queryString1 ="SELECT c FROM CustomerEntity c where c.customerId = 1002";

		String queryString2 ="SELECT c FROM CustomerEntity c where c.city != 'Mysore'";

		String queryString3 ="SELECT c FROM CustomerEntity c where c.dateOfBirth > '1-Jan-1980'";
		String queryString4 ="SELECT c FROM CustomerEntity c where c.dateOfBirth >= '1-Jan-1980'";
		String queryString5 ="SELECT c FROM CustomerEntity c where c.dateOfBirth < '1-Jan-1980'";
		String queryString6 ="SELECT c FROM CustomerEntity c where c.dateOfBirth <= '1-Jan-1980'";
		String queryString7 ="SELECT c FROM CustomerEntity c where c.dateOfBirth BETWEEN '1-Jan-1975' AND '1-Jan-1995'";
		String queryString8 ="SELECT c FROM CustomerEntity c where c.name LIKE 'R%'";
		String queryString9 ="SELECT c FROM CustomerEntity c where c.emailId IS NULL";
		String queryString10 ="SELECT c FROM CustomerEntity c where c.city IN ('Mysore','Pune')";
		String queryString11="SELECT c from CustomerEntity c WHERE SIZE(c.accountEntity) <= 2";

		Query query=entityManager.createQuery(queryString11);

		List<CustomerEntity> result = query.getResultList();

		customerList=new ArrayList<Customer>();

		for (CustomerEntity customerEntity : result) {
			Customer customer=new Customer();
			customer.setCustomerId(customerEntity.getCustomerId());
			customer.setDateOfBirth(customerEntity.getDateOfBirth());
			customer.setEmailId(customerEntity.getEmailId());
			customer.setName(customerEntity.getName());

			List<AccountEntity> accountEntList=customerEntity.getAccountEntity();

			List<Account> accountList=new ArrayList<>();

			if(accountEntList!=null && !accountEntList.isEmpty()){
				for (AccountEntity accountEntity : accountEntList) {
					Account account=new Account();
					account.setAccountNumber(accountEntity.getAccountNumber());
					account.setAccountStatus(accountEntity.getAccountStatus());
					account.setAccountType(accountEntity.getAccountType());
					account.setBalance(accountEntity.getBalance());
					account.setOpeningDate(accountEntity.getOpeningDate());

					accountList.add(account);

				}
			}
			customer.setAccounts(accountList);

			customerList.add(customer);
		}
		return customerList;
	}

}
