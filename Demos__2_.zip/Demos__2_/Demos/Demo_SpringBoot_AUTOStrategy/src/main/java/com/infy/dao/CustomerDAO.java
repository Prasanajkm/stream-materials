package com.infy.dao;

import com.infy.model.Customer;

public interface CustomerDAO {
	public Integer addCustomer(Customer customer) throws Exception;
	
}
