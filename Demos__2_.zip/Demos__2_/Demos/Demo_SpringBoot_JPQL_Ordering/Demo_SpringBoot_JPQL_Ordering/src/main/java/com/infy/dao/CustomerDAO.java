package com.infy.dao;

import java.util.List;

import com.infy.model.Customer;


public interface CustomerDAO {

	public List<Customer> getSortedCustomerList() throws Exception;
	
	
}
