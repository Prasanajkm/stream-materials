package com.infy;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.infy.model.Account;
import com.infy.model.Customer;
import com.infy.service.CustomerService;

@SpringBootApplication
public class DemoSpringBootJpqlSelectApplication implements CommandLineRunner {

	@Autowired
	CustomerService service;

	@Autowired
	Environment environment;

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringBootJpqlSelectApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		getCustomerdetails();
		getCustomerNameAndDOB();
		getCustomerNames();


	}
	public  void getCustomerdetails(){


		try {
			List<Customer> customerList=service.getCustomerdetails();

			System.out.println("\n\nCustomer Details\n------------------------------------------------------------------------");
			System.out.println("CustId\tName\t\tEmailId\t\tDOB\t\tAccount Numbers\n------------------------------------------------------------------------");
			for (Customer c : customerList) {
				System.out.print(c.getCustomerId()+"\t"+c.getName()+"\t"+c.getEmailId()+"\t\t"+c.getDateOfBirth()+"\t");
				String accountDetails="";
				List<Account> accounts=c.getAccounts();

				for (Account account : accounts) {
					accountDetails+=account.getAccountNumber()+", ";
				}

				if(accountDetails!=""){
					System.out.println(accountDetails.substring(0, accountDetails.lastIndexOf(",")));
				}else{
					System.out.println("Account details not available");
				}
			}


		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage(),"Some exception occured. Please check log file for more details!!");
			System.out.println( message);
		}
	}

	public  void getCustomerNameAndDOB() {

		try {
			List<Object[]> result=service.getCustomerNameAndDOB();
			System.out.println("\n\nCustomer Details\n----------------------------------");
			System.out.println("Customer Name\tDOB\n----------------------------------");
			for (Object[] objects : result) {
				System.out.println(objects[0]+"\t\t"+objects[1]);
			}

		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage(),"Some exception occured. Please check log file for more details!!");
			System.out.println( message);
		}



	}
	public  void getCustomerNames() {


		try {
			List<String> customerNames = service.getCustomerName();
			System.out.println("\n\nCustomer Names\n----------------------------------");
			for (String name  : customerNames) {
				System.out.println(name);
			}

		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage(),"Some exception occured. Please check log file for more details!!");
			System.out.println( message);
		}



	}
}

