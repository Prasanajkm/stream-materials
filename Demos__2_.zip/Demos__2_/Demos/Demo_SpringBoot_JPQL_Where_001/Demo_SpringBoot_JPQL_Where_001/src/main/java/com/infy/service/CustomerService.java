package com.infy.service;

import java.util.List;

import com.infy.model.Customer;


public interface CustomerService {

	public List<Customer> getCustomerdetails(Integer customerId) throws Exception;
	
}
