package com.infy.dao;


public interface CustomerDAO {

	public Integer updateCityOfCustomer(Integer customerId, String city) throws Exception;
	public Integer deleteInactiveAccounts() throws Exception;
	
	
}
