package com.infy.service;


public interface CustomerService {

	public Integer updateCityOfCustomer(Integer customerId, String city) throws Exception;
	public Integer deleteInactiveAccounts() throws Exception;
	
}
