package com.infy.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;


@Repository(value="customerDAO")
public class CustomerDAOImpl implements CustomerDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Integer updateCityOfCustomer(Integer customerId, String city)
			throws Exception {
		Query query = entityManager.createQuery("UPDATE CustomerEntity c SET c.city = ?1 where c.customerId = ?2");
		
		query.setParameter(1, city);
		query.setParameter(2, customerId);
		
		int updatedEntities = query.executeUpdate();

		return updatedEntities;
	}

	@Override
	public Integer deleteInactiveAccounts() throws Exception {
		
		Query query = entityManager.createQuery("DELETE FROM AccountEntity a where a.accountStatus = 'INACTIVE'"); 
		
		int deletedEntitiesCount = query.executeUpdate();

		return deletedEntitiesCount;
	}



}
