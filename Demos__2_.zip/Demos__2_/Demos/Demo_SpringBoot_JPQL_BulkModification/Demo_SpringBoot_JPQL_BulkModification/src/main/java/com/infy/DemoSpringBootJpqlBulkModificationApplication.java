package com.infy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.infy.service.CustomerService;

@SpringBootApplication
public class DemoSpringBootJpqlBulkModificationApplication implements CommandLineRunner {

	@Autowired
	CustomerService service;

	@Autowired
	Environment environment;


	public static void main(String[] args) {
		SpringApplication.run(DemoSpringBootJpqlBulkModificationApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

//		updateCityOfEmployee();

		deleteInactiveAccounts();

	}

	public void deleteInactiveAccounts() {

		try {
			
			Integer deleteCount=service.deleteInactiveAccounts();
			System.out.println(environment.getProperty("UserInterface.DELETE_SUCCESS")+deleteCount);

		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage(),"Some exception occured. Please check log file for more details!!");
			System.out.println( message);
		}

	}

	public void updateCityOfEmployee() {
		try {
			Integer updateCount=service.updateCityOfCustomer(1002, "BANGALORE");
			System.out.println(environment.getProperty("UserInterface.UPDATE_SUCCESS")+updateCount);
		} catch (Exception e) {
			String message = environment.getProperty(e.getMessage(),"Some exception occured. Please check log file for more details!!");
			System.out.println( message);
		}

	}

}

