drop table card cascade constraints;
drop table customer cascade constraints;
drop sequence hibernate_sequence;
create sequence hibernate_sequence start with 1006 increment by  1;
create table card (
  card_id number(10) not null,
  card_number varchar2(20),
  expiry_date date,
  cust_id number(10),
  primary key (card_id)
);

create table customer (
  customer_id number(10) not null,
  date_of_birth date,
  emailid varchar2(20),
  name varchar2(20),
  primary key (customer_id)
);
alter table card add constraint fk_card_cust foreign key (cust_id) references customer;

INSERT INTO customer (customer_id, emailid, name, date_of_birth) VALUES (1001,'steven@infy.com', 'Steven Martin', SYSDATE-7476);
INSERT INTO customer (customer_id, emailid, name, date_of_birth) VALUES (1002,'kevin@infy.com', 'Kevin Nelson', SYSDATE-11374);
INSERT INTO customer (customer_id, emailid, name, date_of_birth) VALUES (1003,'john@infy.com', 'John Matric', SYSDATE-12344);
INSERT INTO customer (customer_id, emailid, name, date_of_birth) VALUES (1004,'chan@infy.com', 'Chan mathew', SYSDATE-10344);
INSERT INTO customer (customer_id, emailid, name, date_of_birth) VALUES (1005,'jill@infy.com', 'Jill mathew', SYSDATE-11374);


INSERT INTO card(card_id, card_number,expiry_date,cust_id) VALUES(12346, '6642160005012193',SYSDATE+3400,1001);
INSERT INTO card(card_id, card_number,expiry_date,cust_id) VALUES(12347, '3642140005012179',SYSDATE+4560,1001);
INSERT INTO card(card_id, card_number,expiry_date,cust_id) VALUES(12348, '4642140005012144',SYSDATE+1160,1001);
INSERT INTO card(card_id, card_number,expiry_date,cust_id) VALUES(12349, '5642140005012178',SYSDATE+5660,1002);
INSERT INTO card(card_id, card_number,expiry_date,cust_id) VALUES(12350, '6642140005012177',SYSDATE+5640,1003);
INSERT INTO card(card_id, card_number,expiry_date,cust_id) VALUES(12351, '7642140005012173',SYSDATE+5620,1003);
INSERT INTO card(card_id, card_number,expiry_date,cust_id) VALUES(12352, '7642140005012173',SYSDATE+5620,null);


commit;


select * from card;
select * from customer;
