package com.infy.model;




public class AdharCard {
	
	
	
	private Long adharCardNumber;
	private String address;
	private String phoneNumber;
	public Long getAdharCardNumber() {
		return adharCardNumber;
	}
	public void setAdharCardNumber(Long adharCardNumber) {
		this.adharCardNumber = adharCardNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	//getter and setter methods
	
	
}
