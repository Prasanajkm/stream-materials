package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dao.CustomerDAO;
import com.infy.model.Customer;

@Service(value = "customerService")
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDAO customerDAO;

	public Customer getCustomer(Integer customerId) throws Exception {

		Customer customer = customerDAO.getCustomer(customerId);

		if (customer == null) {

			throw new Exception("Service.CUSTOMER_NOT_FOUND");

		}

		return customer;

	}

	public Integer addCustomer(Customer customer) throws Exception {
		Integer id = null;
		if (customerDAO.getCustomer(customer.getCustomerId()) == null) {
			id = customerDAO.addCustomer(customer);
		} else {
			throw new Exception("Service.CUSTOMER_CANNOT_BE_ADDED");
		}

		return id;
	}

	public Integer updateCustomer(Integer customerId, String emailId)
			throws Exception {

		if (customerDAO.getCustomer(customerId) != null) {
			return customerDAO.updateCustomer(customerId, emailId);
		} else {
			throw new Exception("Service.CUSTOMER_NOT_FOUND");
		}

	}

	public Integer deleteCustomer(Integer customerId) throws Exception {

		if (customerDAO.getCustomer(customerId) != null) {
			return customerDAO.deleteCustomer(customerId);
		} else
			throw new Exception("Service.CUSTOMER_NOT_FOUND");
	}

	public List<Customer> findAllCustomers() throws Exception {
		List<Customer> customers = customerDAO.findAllCustomers();
		if (customers.size() == 0) {
			throw new Exception("Service.NO_CUSTOMER_AVAIALBLE");
		} else
			return customerDAO.findAllCustomers();
	}

	public String getCustomerName(Integer customerId) throws Exception {
		String name = customerDAO.getCustomerName(customerId);

		if (name == null) {
			throw new Exception("Service.CUSTOMER_NOT_FOUND");
		}

		return name;

	}
}
