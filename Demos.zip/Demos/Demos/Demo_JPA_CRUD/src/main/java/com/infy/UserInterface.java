package com.infy;

import java.time.LocalDate;
import com.infy.model.Customer;
import com.infy.service.CustomerService;
import com.infy.service.CustomerServiceImpl;
import com.infy.utility.AppConfig;

public class UserInterface {

	public static CustomerService customerService = new CustomerServiceImpl();

	public static void main(String[] args) {

		addCustomer();
		// getCustomer();
		// updateCustomer();
		// deleteCustomer();

	}

	public static void addCustomer() {

		Customer customer = new Customer();
		customer.setCustomerId(22);
		customer.setEmailId("amit@infy.com");
		customer.setName("Amit Kumar");
		customer.setDateOfBirth(LocalDate.now());

		try {
			Integer id = customerService.addCustomer(customer);
			System.out.println(AppConfig.PROPERTIES
					.getProperty("UserInterface.INSERT_SUCCESS") + id);
		} catch (Exception e) {

			if (e.getMessage() != null)
				System.out
						.println(AppConfig.PROPERTIES.getProperty(
								e.getMessage(),
								"Something went wrong. Please check log file for more details."));
		}

	}

	public static void getCustomer() {
		try {

			Customer customer = customerService.getCustomer(2);

			System.out.println("Customer id : " + customer.getCustomerId());
			System.out.println("Customer name : " + customer.getName());
			System.out.println("Customer email : " + customer.getEmailId());

		} catch (Exception e) {

			if (e.getMessage() != null)
				System.out
						.println(AppConfig.PROPERTIES.getProperty(
								e.getMessage(),
								"Something went wrong. Please check log file for more details."));
		}
	}

	public static void deleteCustomer() {
		try {
			customerService.deleteCustomer(552092);
			System.out.println(AppConfig.PROPERTIES
					.getProperty("UserInterface.DELETE_SUCCESS"));
		} catch (Exception e) {

			if (e.getMessage() != null)
				System.out
						.println(AppConfig.PROPERTIES.getProperty(
								e.getMessage(),
								"Something went wrong. Please check log file for more details."));
		}
	}

	public static void updateCustomer() {
		try {
			customerService.updateCustomer(2, "amit_kumar@infy.com");
			System.out.println(AppConfig.PROPERTIES
					.getProperty("UserInterface.UPDATE_SUCCESS"));
		} catch (Exception e) {

			if (e.getMessage() != null)
				System.out
						.println(AppConfig.PROPERTIES.getProperty(
								e.getMessage(),
								"Something went wrong. Please check log file for more details."));
		}
	}

}
