package com.infy;

import java.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.infy.model.Customer;
import com.infy.service.CustomerServiceImpl;

@SpringBootApplication
public class DemoSpringBootAutoStrategyApplication implements CommandLineRunner {
	@Autowired
	CustomerServiceImpl customerService;

	@Autowired
	Environment environment;


	public static void main(String[] args) {
		SpringApplication.run(DemoSpringBootAutoStrategyApplication.class, args);

	}

	public void run(String... args) throws Exception {

		addCustomer();
	}

	public  void addCustomer() {

		Customer customer = new Customer();
		customer.setEmailId("amit@infy.com");
		customer.setName("Amit Kumar");
		customer.setDateOfBirth(LocalDate.now());

		try {
			Integer id= customerService.addCustomer(customer);
			System.out.println(environment
					.getProperty("UserInterface.INSERT_SUCCESS")+id);
		} catch (Exception e) {


			if (e.getMessage() != null)
				System.out
				.println(environment.getProperty(e.getMessage(),
						"Something went wrong. Please check log file for more details."));
		}

	}

	


}
