package com.infy.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.infy.entity.CustomerEntity;
import com.infy.entity.LoanEntity;
import com.infy.model.Customer;
import com.infy.model.Loan;

//DONT MODIFY NAME OF CLASS
//DONT ADD/MODIFY/DELETE/COMMENT ANY METHOD
//DONT DELETE/MODIFY INSTANCE VARIABLE(IF PRESENT)
//DONT MODIFY ANNOTATIONS(IF PRESENT)
@Repository
public class LoanDAOImpl implements LoanDAO {

	@PersistenceContext
	private EntityManager entityManager;

	
	public List<Customer> getReportByLoanType(String loanType) throws Exception {

		List<Customer> customerList=new ArrayList<Customer>();
		
		Query q = entityManager
				.createQuery("SELECT c FROM CustomerEntity c where lower(c.loan.loanType)=:loanType");
		q.setParameter("loanType", loanType.toLowerCase());
		List<CustomerEntity> customerEntityList = q.getResultList();

		if (customerEntityList.isEmpty()) {
			return customerList;
		}

		
		for (CustomerEntity ce : customerEntityList) {
			Customer c = new Customer();
			c.setCustomerId(ce.getCustomerId());
			c.setCustomerName(ce.getCustomerName());
			c.setMobileNo(ce.getMobileNo());

			Loan l = new Loan();

			l.setLoanId(ce.getLoan().getLoanId());
			l.setLoanAmount(ce.getLoan().getLoanAmount());
			l.setInterestRate(ce.getLoan().getInterestRate());
			l.setLoanAmount(ce.getLoan().getLoanAmount());
			l.setLoanType(ce.getLoan().getLoanType());
			// l.setTotalAmount(ce.g);
			l.setTerm(ce.getLoan().getTerm());
			Double emi = (ce.getLoan().getLoanAmount() + ((ce.getLoan()
					.getLoanAmount() * ce.getLoan().getTerm() * ce.getLoan()
					.getInterestRate()) / 100)) / (ce.getLoan().getTerm() * 12);
			c.setEmi(Math.ceil(emi));
			c.setLoan(l);
			customerList.add(c);
		}

		return customerList;

	}

	
	public Integer checkLoanAllotment(Integer customerId) throws Exception {
		CustomerEntity customerEntity=entityManager.find(CustomerEntity.class, customerId);
		if(customerEntity==null)
			return -1;
		LoanEntity loanEntity=customerEntity.getLoan();
		if(loanEntity==null)
			return 0;	
		return loanEntity.getLoanId();
	}
	
	public Integer sanctionLoan(Customer customer) throws Exception {
		CustomerEntity customerEntity=entityManager.find(CustomerEntity.class, customer.getCustomerId());
		LoanEntity loanEntity=new LoanEntity();
		Loan loan=customer.getLoan();
		loanEntity.setLoanAmount(loan.getLoanAmount());
		loanEntity.setLoanId(loan.getLoanId());
		loanEntity.setLoanType(loan.getLoanType());
		if(loan.getLoanType().equals("HomeLoan"))
		{
		loanEntity.setInterestRate(13.0);
		loanEntity.setTerm(15);
		}
		else
		{
			loanEntity.setInterestRate(9.0);
			loanEntity.setTerm(5);
		}
		customerEntity.setLoan(loanEntity);
		entityManager.persist(loanEntity);
		return loanEntity.getLoanId();
	}
}
