package com.infy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.infy.dao.LoanDAO;
import com.infy.model.Customer;
import com.infy.validator.Validator;
//DONT MODIFY NAME OF CLASS
//DONT ADD/MODIFY/DELETE/COMMENT ANY METHOD
//DONT DELETE/MODIFY INSTANCE VARIABLE(IF PRESENT)
//DONT MODIFY ANNOTATIONS(IF PRESENT)
@Repository(value="loanService")
@Transactional
public class LoanServiceImpl implements LoanService {
	@Autowired
	private LoanDAO loanDAO;
	@Override
	public Integer sanctionLoan(Customer customer) throws Exception {
		Validator validate=new Validator();
		Validator.validate(customer.getLoan());
		Integer  l=loanDAO.checkLoanAllotment(customer.getCustomerId());
		if(l==0)
		{
			return loanDAO.sanctionLoan(customer);
			
		}
		if(l==-1)
			throw new Exception("Service.CUSTOMER_UNAVAILABLE");
		throw new Exception("Service.LOAN_ALREADY_TAKEN");
	}
	@Override
	public List<Customer> getReportByLoanType(String loanType) throws Exception {
		List<Customer> list=loanDAO.getReportByLoanType(loanType);
		if(list.isEmpty())
			throw new Exception("Service.NO_LOAN_FOUND");
		return list;
	}

}
