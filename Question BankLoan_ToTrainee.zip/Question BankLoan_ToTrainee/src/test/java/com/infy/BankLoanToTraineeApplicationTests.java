package com.infy;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.infy.dao.LoanDAO;
import com.infy.model.Customer;
import com.infy.model.Loan;
import com.infy.service.LoanService;

//DONT MODIFY NAME OF CLASS
//DONT ADD/MODIFY/DELETE ANY METHOD
//DONT DELETE/MODIFY INSTANCE VARIABLE(IF PRESENT)
//DONT MODIFY ANNOTATIONS(IF PRESENT)

@RunWith(SpringRunner.class)
@SpringBootTest
public class BankLoanToTraineeApplicationTests {

	@Rule
	ExpectedException expectedException = ExpectedException.none();
	@Mock
	LoanDAO loanDAO;
	@InjectMocks
	LoanService loanService;
	@Test
	public void sanctionLoanCustomerNotAvailableTest() throws Exception {
		expectedException.expect(Exception.class);
		expectedException.expectMessage("Service.CUSTOMER_UNAVAILABLE");
		Customer customer=new Customer();
		customer.setCustomerId(2001);
		customer.setCustomerName("Markel");
		customer.setEmi(2.0);
		customer.setMobileNo(9488607323L);
		Loan loan=new Loan();
		loan.setInterestRate(12.5);
		loan.setLoanAmount(700000.0);
		loan.setLoanId(1001);
		loan.setLoanType("HomeLoan");
		loan.setTerm(5645);
		Mockito.when(loanDAO.checkLoanAllotment(customer.getCustomerId())).thenReturn(-1);
		loanService.sanctionLoan(customer);
	}
	
	public void sanctionLoanLoanAlreadyTakenTest() throws Exception {
		expectedException.expect(Exception.class);
		expectedException.expectMessage("Service.CUSTOMER_UNAVAILABLE");
		Customer customer=new Customer();
		customer.setCustomerId(2001);
		customer.setCustomerName("Markel");
		customer.setEmi(2.0);
		customer.setMobileNo(9488607323L);
		Loan loan=new Loan();
		loan.setInterestRate(12.5);
		loan.setLoanAmount(700000.0);
		loan.setLoanId(1001);
		loan.setLoanType("HomeLoan");
		loan.setTerm(5645);
		Mockito.when(loanDAO.checkLoanAllotment(customer.getCustomerId())).thenReturn(1007);
		loanService.sanctionLoan(customer);
	}

}
