//Typescipt class which contains the details of Aadharcard
export class AadharCard {
    aadharNumber: string;
    name: string;
	dateOfBirth: Date;
	address: string;
	phoneNumber: string;
	message: string;
}